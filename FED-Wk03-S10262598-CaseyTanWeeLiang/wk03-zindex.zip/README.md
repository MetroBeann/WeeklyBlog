1. Select the class logo and give it absolute positioning.
2. Next, give .logo a top offset of -45px and a left offset of 125px.
3. The logo's absolute position is relative to the browser viewport. Make .card the new positioning context for .logo.

-END-